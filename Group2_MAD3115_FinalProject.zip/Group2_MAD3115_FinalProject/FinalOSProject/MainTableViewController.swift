//
//  MainTableViewController.swift
//  FinalOSProject
//
//  Created by Jasvir Kaur on 2018-11-18.
//  Copyright © 2018 Lampton. All rights reserved.
//

import UIKit

class MainTableViewController: UITableViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        // Uncomment the following line to preserve selection between presentations
        // self.clearsSelectionOnViewWillAppear = false

        // Uncomment the following line to display an Edit button in the navigation bar for this view controller.
        // self.navigationItem.rightBarButtonItem = self.editButtonItem
    }

    // MARK: - Table view data source

    override func numberOfSections(in tableView: UITableView) -> Int {
        // #warning Incomplete implementation, return the number of sections
        return 2
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of rows
         return section == 0 ? 3 : 4
    }
    
    func toaddticket(){
        
        let sb = UIStoryboard(name: "Main", bundle: nil)
        let addVC = sb.instantiateViewController(withIdentifier: "addVC") as! AddTicketViewController
      
        self.present(addVC, animated: true, completion: nil)
        
        // self.navigationController?.pushViewController(addVC, animated: true)
    }
    
    func tolocation(){
        
        let sb = UIStoryboard(name: "Main", bundle: nil)
        let locationVC = sb.instantiateViewController(withIdentifier: "locationVC") as! LocationViewController
        self.present(locationVC, animated: true, completion: nil)
        
        //self.navigationController?.pushViewController(locationVC, animated: true)
        
    }
    
    func topayreceipt()
    {
        let sb = UIStoryboard(name: "Main", bundle: nil)
        let preceiptVC = sb.instantiateViewController(withIdentifier: "preceiptVC") as! PayreceiptViewController
        self.present(preceiptVC, animated: true, completion: nil)
        // self.navigationController?.pushViewController(preceiptVC, animated: true)
    }
    
    
    func toUser()
    {
        let sb = UIStoryboard(name: "Main", bundle: nil)
        let userVC = sb.instantiateViewController(withIdentifier: "userVC") as! UserProfileViewController
        self.present(userVC, animated: true, completion: nil)
        // self.navigationController?.pushViewController(preceiptVC, animated: true)
    }
    
    func toinstruction()
    {
        let sb = UIStoryboard(name: "Main", bundle: nil)
        let insVC = sb.instantiateViewController(withIdentifier: "insVC") as! InstructionViewController
        self.present(insVC, animated: true, completion: nil)
        // self.navigationController?.pushViewController(insVC, animated: true)
    }
    
    func tocontact()
    {
        let sb = UIStoryboard(name: "Main", bundle: nil)
        let contactVC = sb.instantiateViewController(withIdentifier: "contactVC") as! ContactViewController
        self.present(contactVC, animated: true, completion: nil)
        // self.navigationController?.pushViewController(contactVC, animated: true)
    }
    
    func logout(){
        
        let sb = UIStoryboard(name: "Main", bundle: nil)
        let loginVC = sb.instantiateViewController(withIdentifier: "loginVC") 
        self.present(loginVC, animated: true, completion: nil)
        
        //  self.navigationController?.pushViewController(loginVC, animated: true)
    }
    
    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        if tableView.indexPathForSelectedRow?.section == 0{
            
            
            if indexPath.row == 0{
                toaddticket()
            }else if indexPath.row == 1{
                tolocation()
            }else {
                topayreceipt()
                
            }
        } else if tableView.indexPathForSelectedRow?.section == 1{
            switch indexPath.row{
            case 0:
                toUser()
            case 1:
                tocontact()
            case 2:
                toinstruction()
            case 3:
                logout()
                
                
                
            default:
                print("nothing")
            }
            
            
        }
        
        
    }
    

    /*
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "reuseIdentifier", for: indexPath)

        // Configure the cell...

        return cell
    }
    */

    /*
    // Override to support conditional editing of the table view.
    override func tableView(_ tableView: UITableView, canEditRowAt indexPath: IndexPath) -> Bool {
        // Return false if you do not want the specified item to be editable.
        return true
    }
    */

    /*
    // Override to support editing the table view.
    override func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCellEditingStyle, forRowAt indexPath: IndexPath) {
        if editingStyle == .delete {
            // Delete the row from the data source
            tableView.deleteRows(at: [indexPath], with: .fade)
        } else if editingStyle == .insert {
            // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
        }    
    }
    */

    /*
    // Override to support rearranging the table view.
    override func tableView(_ tableView: UITableView, moveRowAt fromIndexPath: IndexPath, to: IndexPath) {

    }
    */

    /*
    // Override to support conditional rearranging of the table view.
    override func tableView(_ tableView: UITableView, canMoveRowAt indexPath: IndexPath) -> Bool {
        // Return false if you do not want the item to be re-orderable.
        return true
    }
    */

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
