//
//  SignupViewController.swift
//  FinalOSProject
//
//  Created by Jasvir Kaur on 2018-11-12.
//  Copyright © 2018 Lampton. All rights reserved.
//

import UIKit

class SignupViewController: UIViewController {
    var User = UserProfile()

    @IBOutlet weak var Name: UITextField!
    
    @IBOutlet weak var ContactNumber: UITextField!
    
    @IBOutlet weak var EmailID: UITextField!
    
    @IBOutlet weak var Password: UITextField!
    
    @IBOutlet weak var VehicleBrand: UITextField!
    @IBOutlet weak var VehicleColor: UITextField!
    @IBOutlet weak var VehicleNumber: UITextField!
    @IBOutlet weak var ConfirmPassword: UITextField!
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    
    @IBAction func Register(_ sender: UIButton) {
        
        
        if (Name.text!.isEmpty || EmailID.text!.isEmpty || Password.text!.isEmpty || ContactNumber.text!.isEmpty || ConfirmPassword.text!.isEmpty || VehicleColor.text!.isEmpty || VehicleNumber.text!.isEmpty || VehicleBrand.text!.isEmpty) {
            let infoAlert = UIAlertController(title: "Error", message: "Fields cannot be empty", preferredStyle: .alert)
            infoAlert.addAction(UIAlertAction(title: "Try Again", style: .destructive, handler: nil))
            self.present(infoAlert, animated: true, completion: nil)
        }
        
        self.User.Name = self.Name.text
        self.User.ContactNumber = self.ContactNumber.text
        self.User.Password = self.Password.text
        self.User.EmailID = self.EmailID.text
        self.User.VehicleNumber = self.VehicleNumber.text
        self.User.VehicleBrand = self.VehicleBrand.text
        self.User.VehicleColor = self.VehicleColor.text
        
        let _ = Database.save("insert into User (Name, ContactNumber,  Email, Password,VehicleNumber ,  VehicleBrand , VehicleColor  ) values(? , ?, ?, ?,?,?,?)", [self.User.Name , self.User.ContactNumber , self.User.EmailID, self.User.Password, self.User.VehicleNumber, self.User.VehicleBrand, self.User.VehicleColor] )
        
        //let _ = Database.save("insert into User (Name, ContactNumber,  Email, Password,VehicleNumber ,  VehicleBrand , VehicleColor  ) values(? , ?, ?, ?,?,?,?)", [self.Name.text , self.ContactNumber.text , self.EmailID.text, self.Password.text, self.VehicleNumber.text, self.VehicleBrand.text, self.VehicleColor.text] )
        
        
        
        
        login()
    }
    
    func user()
    {
        let sb = UIStoryboard(name: "Main", bundle: nil)
        let userVC = sb.instantiateViewController(withIdentifier: "userVC") as! UserProfileViewController
        userVC.previousPage1 = self
        self.navigationController?.pushViewController(userVC, animated: true)
        self.present(userVC, animated: true, completion: nil)
        
    }
    func login(){
        
        let sb = UIStoryboard(name: "Main", bundle: nil)
        let loginVC = sb.instantiateViewController(withIdentifier: "loginVC") 
        
        self.present(loginVC, animated: true, completion: nil)
        

            self.navigationController?.popViewController(animated: true)
        }
    
    
        
    
    
    
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */


}
