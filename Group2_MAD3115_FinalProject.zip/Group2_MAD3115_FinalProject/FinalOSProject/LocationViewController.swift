//
//  LocationViewController.swift
//  FinalOSProject
//
//  Created by Jasvir Kaur on 2018-11-17.
//  Copyright © 2018 Lampton. All rights reserved.
//

import UIKit
 import MapKit

class LocationViewController: UIViewController, UISearchBarDelegate {
    
    

    @IBOutlet weak var Mapview: MKMapView!
    
            let initialLocation = CLLocation(latitude: 43.7733, longitude: -79.3359)
            var searchController: UISearchController!
            let regionRadius: CLLocationDistance = 1000
            
            
            override func viewDidLoad() {
                super.viewDidLoad()
                
                let coordinateRegion = MKCoordinateRegion(center: initialLocation.coordinate, latitudinalMeters: regionRadius * 2.0, longitudinalMeters: regionRadius * 2.0)
                self.Mapview.setRegion(coordinateRegion, animated: true)
                // Do any additional setup after loading the view, typically from a nib.
                // Drop a pin at user's Current Location
                let myAnnotation: MKPointAnnotation = MKPointAnnotation()
                myAnnotation.coordinate = CLLocationCoordinate2DMake(initialLocation.coordinate.latitude, initialLocation.coordinate.longitude);
                myAnnotation.title = "Toronto"
                myAnnotation.subtitle = "City Hall, King St. W"
                self.Mapview.addAnnotation(myAnnotation)
                
            }
            
    @IBAction func mapsegment(_ sender: UISegmentedControl) {
    
                
                switch sender.selectedSegmentIndex {
                case 0:
                    Mapview.mapType = MKMapType.standard
                case 1:
                    Mapview.mapType = MKMapType.satellite
                case 2:
                    Mapview.mapType = MKMapType.hybrid
                default:
                    Mapview.mapType = MKMapType.standard
                }
                
                
            }
            
            @IBAction func searchBarButton(_ sender: UIBarButtonItem) {
                
                
                searchController = UISearchController(searchResultsController: nil)
                searchController.hidesNavigationBarDuringPresentation = false
                self.searchController.searchBar.delegate = self
                present(searchController, animated: true, completion: nil)
            }
            
            func searchBarSearchButtonClicked(_ searchBar: UISearchBar) {
                searchBar.resignFirstResponder()
                dismiss(animated: true, completion: nil)
                print("Search Click")
                print(searchBar.text!)
            }
            
        }
        

        // Do any additional setup after loading the view.
    
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */


