//
//  PayreceiptViewController.swift
//  FinalOSProject
//
//  Created by Jasvir Kaur on 2018-11-17.
//  Copyright © 2018 Lampton. All rights reserved.
//

import UIKit

class PayreceiptViewController: UIViewController {
  
    public var previousPage : UIViewController?
    
    @IBOutlet weak var Email: UITextField!
    
    
    @IBOutlet weak var Vehiclenumber: UITextField!
    
    @IBOutlet weak var Vehiclebrand: UITextField!
    
    @IBOutlet weak var Lotnumebr: UITextField!
    
    @IBOutlet weak var Date: UITextField!
    @IBOutlet weak var Paymethod: UITextField!
    @IBOutlet weak var Payamount: UITextField!
    @IBOutlet weak var Slotnumber: UITextField!
    @IBOutlet weak var VehicleColor: UITextField!
    override func viewDidLoad() {
        super.viewDidLoad()
Database.init()
        
        var pp = self.previousPage as! AddTicketViewController
        
            self.Email.text = pp.EmailID.text
        self.Vehiclebrand.text = pp.VBrand.text
        self.Lotnumebr.text = pp.Lotnumber.text
        self.Vehiclenumber.text = pp.VNumber.text
        self.Slotnumber.text = pp.Spotnumber.text
        self.VehicleColor.text = pp.VColor.text
        self.Payamount.text = pp.Amounttopay.text
        self.Date.text = pp.Date.text
            self.Paymethod.text = pp.PaymentMethod.text
       // newTable = "CREATE TABLE IF NOT EXISTS Ticket (Email TEXT PRIMARY KEY , number TEXT,Brand TEXT, Color TEXT, hoursParked REAL, date NUMERIC, lotNumber INTEGER, SpotNumber INTEGER, PaymentMethod REAL, PaymentAmount REAL)"
        // Do any additional setup after loading the view.
    }
    
    
    
   /* @IBAction func Receipt(_ sender: UIButton) {
        
        let sql = "select * from Ticket where Email = ? and number = ?"
        
        
        let test = Database.select(sql, [Email.text, Vehiclenumber.text])
        
        print("\(test)")*/
        
        //let results = Database.select(sql, [login as Any, password as Any])
        
        
    }
    


    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */


