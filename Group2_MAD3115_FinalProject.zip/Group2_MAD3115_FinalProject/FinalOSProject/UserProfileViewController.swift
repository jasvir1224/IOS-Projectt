//
//  UserProfileViewController.swift
//  FinalOSProject
//
//  Created by Jasvir Kaur on 2018-11-18.
//  Copyright © 2018 Lampton. All rights reserved.
//

import UIKit

class UserProfileViewController: UIViewController {
    
    var User = UserProfile()

    @IBOutlet weak var Name: UITextField!
    
    @IBOutlet weak var Email: UITextField!
    
    @IBOutlet weak var ContactNumber: UITextField!
    public var previousPage1 : UIViewController?

    
    @IBOutlet weak var VehicleNumber: UITextField!
    
    
    @IBOutlet weak var VehicleBrand: UITextField!
    
    
    @IBOutlet weak var VehicleColor: UITextField!
    
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        
        Database.init()
        //var rr = self.previousPage1 as! SignupViewController
       
        self.Email.text = self.User.EmailID
        self.VehicleBrand.text = self.User.VehicleBrand
        self.ContactNumber.text = self.User.ContactNumber
        self.Name.text = self.User.Name
        self.VehicleNumber.text = self.User.VehicleNumber
        self.VehicleColor.text = self.User.VehicleColor

        // Do any additional setup after loading the view.
    }
    
    @IBAction func ProfileButton(_ sender: UIButton) {
        
       // let sql = "select * from User where Email = ? and Name = ?"

        
        self.User.Name = self.Name.text
        self.User.EmailID = self.Email.text
        self.User.ContactNumber = self.ContactNumber.text
        self.User.VehicleNumber = self.VehicleNumber.text
        self.User.VehicleBrand = self.VehicleBrand.text
        self.User.VehicleColor = self.VehicleColor.text
    }
    
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
