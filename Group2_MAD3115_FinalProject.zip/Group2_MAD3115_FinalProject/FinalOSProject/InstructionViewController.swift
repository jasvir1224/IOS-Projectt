//
//  InstructionViewController.swift
//  FinalOSProject
//
//  Created by Jasvir Kaur on 2018-11-18.
//  Copyright © 2018 Lampton. All rights reserved.
//

import UIKit
import WebKit

class InstructionViewController: UIViewController {

    @IBOutlet weak var WebView: WKWebView!
    override func viewDidLoad() {
        super.viewDidLoad()
loadFromFile()
        // Do any additional setup after loading the view.
    }
    func loadFromFile()
    {
        let localfilePath = Bundle.main.url(forResource: "Instruction", withExtension: "html");
        let myRequest = URLRequest(url: localfilePath!);
        self.WebView.load(myRequest)
    }

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
