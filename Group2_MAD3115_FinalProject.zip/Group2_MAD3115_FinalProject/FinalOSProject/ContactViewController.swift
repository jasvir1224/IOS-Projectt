//
//  ContactViewController.swift
//  FinalOSProject
//
//  Created by Jasvir Kaur on 2018-11-18.
//  Copyright © 2018 Lampton. All rights reserved.
//

import UIKit

import MessageUI

class ContactViewController: UIViewController, MFMessageComposeViewControllerDelegate, MFMailComposeViewControllerDelegate{
    
    @IBOutlet weak var Subject: UITextField!
    
    
    @IBOutlet weak var Message: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    
    func messageComposeViewController(_ controller: MFMessageComposeViewController, didFinishWith result: MessageComposeResult)
    {
        switch (result)
        {
        case .cancelled:
            print ("Message was cancelled")
            
        case .failed:
            print ("Message was failed")
            
        case .sent:
            print ("Message was sent")
            
        }
        self.dismiss(animated: true, completion: nil)
    }
    
    func mailComposeController(_ controller: MFMailComposeViewController, didFinishWith result: MFMailComposeResult, error: Error?) {
        switch (result)
        {
        case .cancelled:
            print ("Email sending cancelled")
            
        case .failed:
            print ("Email sending failed")
            
        case .saved:
            print ("Email saved to the draft")
            
        case .sent:
            print ("Email sent successfully")
            
        }
        self.dismiss(animated: true, completion: nil)
    }
    
    
    @IBAction func SendSMS(_ sender: UIButton) {
        
        if MFMessageComposeViewController.canSendText()
        {
            let messageVC = MFMessageComposeViewController()
            
            messageVC.body = "Hello, How are you?"//NSLocalizedString("STR_SUBJECT", comment: "")
            messageVC.recipients = ["+16476164491"]
            messageVC.messageComposeDelegate = self
            
            self.present(messageVC, animated: false, completion: nil)
        }
        else
        {
            print("NO SIM Available")
        }
    }
    
    @IBAction func SendEmail(_ sender: UIButton) {
        
        if MFMailComposeViewController.canSendMail()
        {
            let picker = MFMailComposeViewController()
            picker.mailComposeDelegate = self
            picker.setSubject(Subject.text!)
            picker.setToRecipients(["DiljitSingh@gmail.com"])
            picker.setMessageBody(Message.text!, isHTML: true)
            //        {
            //            if let path = Bundle,main.path(forResource: "car" ofType: "png")
            //            {
            //
            //            }
            //        }
            present(picker, animated:true, completion: nil)
        }
    }
    
    
    @IBAction func ContactUs(_ sender: UIButton) {
        if let url = URL(string: "tel://+16476164491"), UIApplication.shared.canOpenURL(url)
        {
            if #available(iOS 10, *, *)
            {
                UIApplication.shared.open(url)
            }
            else
            {
                UIApplication.shared.openURL(url)
            }
        }
    }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
