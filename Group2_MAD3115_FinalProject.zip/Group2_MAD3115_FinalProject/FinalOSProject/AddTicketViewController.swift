//
//  AddTicketViewController.swift
//  FinalOSProject
//
//  Created by Jasvir Kaur on 2018-11-16.
//  Copyright © 2018 Lampton. All rights reserved.
//

import UIKit

class AddTicketViewController: UIViewController {
  

    @IBOutlet weak var EmailID: UITextField!
    
    @IBOutlet weak var VNumber: UITextField!
    
    @IBOutlet weak var VBrand: UITextField!
    
    @IBOutlet weak var VColor: UITextField!
    
    @IBOutlet weak var DateLabel: UILabel!
    
    @IBOutlet weak var DatePick: UIDatePicker!
    
    @IBOutlet weak var Spotnumber: UITextField!
    
    @IBOutlet weak var Lotnumber: UITextField!
    @IBOutlet weak var Amounttopay: UITextField!
    @IBOutlet weak var Date: UITextField!
    
    
    @IBOutlet weak var PaymentMethod: UITextField!
   // var datePicker =  UIDatePicker()
    let datePicker = UIDatePicker()
    override func viewDidLoad() {
        super.viewDidLoad()
        Database.init()
        showDatePicker()
        
        /*datePicker?.datePickerMode = .date
        datePicker?.addTarget(self, action: #selector(AddTicketViewController.datePickerValueChanged(sender:)), for: .valueChanged)
        
        let tapGesture = UITapGestureRecognizer(target: self, action: #selector(AddTicketViewController.viewtapped(gestureRecognizer:)))

        view.addGestureRecognizer(tapGesture)
        DateandTime.inputView = datePicker*/
        /*let datePickerView:UIDatePicker = UIDatePicker()
        datePickerView.datePickerMode = UIDatePicker.Mode.date
        DateandTime.inputView = datePickerView
        DatePick.addTarget(self, action: #selector(AddTicketViewController.datePickerValueChanged(sender:)), for: UIControl.Event.valueChanged)*/
        
        // Do any additional setup after loading the view.
        
        }
    
    func showDatePicker(){
        
        datePicker.datePickerMode = .date
        
       
        let toolbar = UIToolbar();
        toolbar.sizeToFit()
        let doneButton = UIBarButtonItem(title: "Done", style: .plain, target: self, action: #selector(donedatePicker))
       let spaceButton = UIBarButtonItem(barButtonSystemItem: UIBarButtonItem.SystemItem.flexibleSpace, target: nil, action: nil)
        
        let cancelButton =  UIBarButtonItem(title: "Cancel", style: .plain, target: self, action: #selector(cancelDatePicker))
       
    
        
        toolbar.setItems([doneButton,spaceButton,cancelButton], animated: false)
        
        Date.inputAccessoryView = toolbar
        Date.inputView = datePicker
        
    }
    
    @objc func donedatePicker(){
        
        let formatter = DateFormatter()
        formatter.dateFormat = "dd/MM/yyyy"
        Date.text = formatter.string(from: datePicker.date)
        self.view.endEditing(true)
    }

    
    
    
   // @objc func viewtapped(gestureRecognizer: UITapGestureRecognizer){
     //   view.endEditing(true)
    //}
    
    /* @objc func datePickerValueChanged(sender:UIDatePicker) {
        
        let dateFormatter = DateFormatter()
        
        dateFormatter.dateFormat = "MM/dd/yyyy"
        
        DateandTime.text = dateFormatter.string(from: sender.date)
        view.endEditing(true)
        
    }*/
    
    @objc func cancelDatePicker(){
        self.view.endEditing(true)
    }
    
    
   
   

    @IBAction func Parkinghours(_ sender: UISegmentedControl) {
        
        
        switch sender.selectedSegmentIndex
        {
        case 1:
            self.Amounttopay.text = "$ 4.00"
        case 2:
            self.Amounttopay.text = "$ 12.00"
        case 3:
            self.Amounttopay.text = "$ 15.00"
         case 4:
            self.Amounttopay.text = "$ 18.00"
          default:
            self.Amounttopay.text = "$ 10.00"
            

        }
        
    }

    @IBAction func Paymethod(_ sender: UISegmentedControl) {
    
    switch sender.selectedSegmentIndex
        {
        case 1:
            self.PaymentMethod.text = "Debit"
        case 2:
            self.PaymentMethod.text = "Credit"
        default:
            self.PaymentMethod.text = "Visa"
            
            
        }
    
    }
    @IBAction func SaveButton(_ sender: UIButton) {
        
        let _ =  Database.save("insert into Ticket (Email,  number, Brand, Color ,lotNumber ,SpotNumber, PaymentMethod,PaymentAmount) values(? ,?,?,?,?, ?, ?, ?)", [self.EmailID.text , self.VNumber.text, self.VBrand.text, self.VColor.text, self.Lotnumber.text , self.Spotnumber.text, self.PaymentMethod.text ,self.Amounttopay.text ])
       
        let alert = UIAlertController(title: title, message: "Save", preferredStyle: UIAlertController.Style.alert)
        
        let cancelAction = UIAlertAction(title: "OK",
                                         style: .cancel, handler: {_ in self.toreceipt()})
        
        
        
        alert.addAction(cancelAction)
        self.present(alert, animated: true, completion: nil)
        
        
        //let pam = String(ticket * totalamount
        
    }

    func toreceipt()
    {
        let sb = UIStoryboard(name: "Main", bundle: nil)
        let preceiptVC = sb.instantiateViewController(withIdentifier: "preceiptVC") as! PayreceiptViewController
        
       preceiptVC.previousPage = self
        self.navigationController?.pushViewController(preceiptVC, animated: true)
        self.present(preceiptVC, animated: true, completion: nil)

    }
    
    
    
 
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
