//
//  ViewController.swift
//  FinalOSProject
//
//  Created by Jasvir Kaur on 2018-11-10.
//  Copyright © 2018 Lampton. All rights reserved.
//

import UIKit

class LoginViewController: UIViewController {

    @IBOutlet weak var EmailID: UITextField!
    @IBOutlet weak var Password: UITextField!
    @IBOutlet weak var ConfirmPassword: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        Database.init()
        // Do any additional setup after loading the view, typically from a nib.
    }

    @IBAction func LoginButton(_ sender: UIButton) {
        
        if let path=Bundle.main.path(forResource: "Customer", ofType: "plist")
        {
            if let content = NSDictionary(contentsOfFile: path) as? [String:AnyObject]
            {
                let  Users = content["Customer"] as! [AnyObject]
                for user in Users
                {
                    let emailid = user["EmailID"] as! String
                    let password = user["Password"] as! String
                    let confirmpassword = user["ConfirmPassword"] as! String
                    
                   
                    
                    let sql = "select * from User where Email = ? and Password = ?"
                    let results = Database.select(sql, [EmailID.text as Any, Password.text as Any])
                    
                    if (EmailID.text?.isEmpty)! || (Password.text?.isEmpty)! || (ConfirmPassword.text?.isEmpty)!{
                        showError()
                    }
                    
                    if results.count > 0 || ((emailid == EmailID.text && password == Password.text) && (password == Password.text && confirmpassword == ConfirmPassword.text))
                    {
                        let alert = UIAlertController(title: title, message: "Welcome", preferredStyle: UIAlertController.Style.alert)
                        
                        let cancelAction = UIAlertAction(title: "OK",
                                                         style: .cancel, handler: {_ in self.tonextScreen()})
                        
                        
                        
                        alert.addAction(cancelAction)
                        self.present(alert, animated: true, completion: nil)
                    } else {
                        let alert = UIAlertController(title: "Error", message: "Username or Password is incorrect", preferredStyle: UIAlertController.Style.alert)
                        
                        
                        let cancelAction = UIAlertAction(title: "OK",
                                                         style: .cancel, handler: {_ in self.register()})
                        
                        alert.addAction(cancelAction)
                        self.present(alert, animated: true, completion: nil)
                    }
                    
                }
            }
            
        }
        
    }
    func showError(){
        let infoAlert = UIAlertController(title: "Error", message: "Email and password field cannot be empty", preferredStyle: .alert)
        infoAlert.addAction(UIAlertAction(title: "Try Again", style: .default, handler: nil))
        self.present(infoAlert, animated: true, completion: nil)
    }
    
    
    func tonextScreen(){
        
        let sb = UIStoryboard(name: "Main", bundle: nil)
        let mainVC = sb.instantiateViewController(withIdentifier: "mainVC")
        self.present(mainVC, animated: true, completion: nil)
        
        self.navigationController?.pushViewController(mainVC, animated: true)
        
    }
    
    
    func register(){
        
        let sb = UIStoryboard(name: "Main", bundle: nil)
        let signupVC = sb.instantiateViewController(withIdentifier: "signupVC")
        self.present(signupVC, animated: true, completion: nil)
        
        self.navigationController?.pushViewController(signupVC, animated: true)
        
    }
    

    
    @IBAction func SignUpButton(_ sender: UIButton) {
        register()
    }
    
}


