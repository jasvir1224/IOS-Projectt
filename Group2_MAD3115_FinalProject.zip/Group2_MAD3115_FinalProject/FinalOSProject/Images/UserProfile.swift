//
//  UserProfile.swift
//  FinalOSProject
//
//  Created by Jasvir Kaur on 2018-11-19.
//  Copyright © 2018 Lampton. All rights reserved.
//

import Foundation

class UserProfile
{
    var Name : String?
    var EmailID : String?
    var Password : String?
    var ContactNumber : String?
    var VehicleNumber : String?
    var VehicleBrand : String?
    var VehicleColor : String?
    
    init() {
        
    }
    
  
    
    init(Name : String, EmailID : String, Password : String, ContactNumber : String, VehicleNumber : String,    VehicleBrand : String, VehicleColor : String)
    {
        
        self.Name = Name
        self.EmailID = EmailID
        self.Password = Password
        self.ContactNumber = ContactNumber
        self.VehicleNumber = VehicleNumber
        self.VehicleBrand = VehicleBrand
        self.VehicleColor = VehicleColor
    }
    
    static func parse(_ newUser : Dictionary<String, AnyObject>) -> UserProfile
    {
        let u = UserProfile()
        for (k, v) in newUser
        {
            let value : String = v as! String
            switch k
            {
            case "Name":
                u.Name = value
            case "Email":
                u.EmailID = value
            case "Password":
                u.Password = value
            case "ContactNumber":
                u.ContactNumber = value
            case "VehicleNumber":
                u.VehicleNumber = value
            case "VehicleBrand":
                u.VehicleBrand = value
            case "VehicleColor":
                u.VehicleBrand = value
            default: break
            }
        }
        return u
    }
    
    func unParse() -> Dictionary<String, AnyObject>
    {
        let dict : [String : AnyObject] =
            [
               
                "Name" : self.Name as AnyObject,
                "EmailID" : self.EmailID as AnyObject,
                "Password" : self.Password as AnyObject,
                "ContactNumber" : self.ContactNumber as AnyObject,
                "VehicleNumber" : self.VehicleNumber as AnyObject,
                "VehicleBrand" : self.VehicleBrand as AnyObject,
                "VehicleColor" : self.VehicleColor as AnyObject
        ]
        return dict
        
    }
}

    

